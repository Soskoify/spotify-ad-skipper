package com.spotify.adskipper

import android.content.Context

/** Tiny SharedPreferences wrapper for Soskoify settings. */
object SkipPrefs {
    private const val FILE = "soskoify"
    private const val KEY_HIDDEN_DISPLAY = "hidden_display"

    /** When true, Spotify is relaunched on an off-screen virtual display. Default on. */
    fun hiddenDisplay(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_HIDDEN_DISPLAY, true)

    fun setHiddenDisplay(context: Context, value: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_HIDDEN_DISPLAY, value).apply()
    }
}
