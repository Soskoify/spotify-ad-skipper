package com.spotify.adskipper

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log

/**
 * Owns an off-screen virtual display. Spotify is relaunched here after an ad skip so it never
 * appears on the real screen. The display has no physical output: frames go into an ImageReader
 * that immediately discards them.
 *
 * The display lives as long as this process does (the notification listener keeps it alive).
 */
object HiddenDisplay {

    private const val TAG = "HiddenDisplay"
    private const val WIDTH = 720
    private const val HEIGHT = 1280
    private const val DPI = 320

    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    /** Returns the id of the hidden display, creating it if needed. Null if creation failed. */
    @Synchronized
    fun ensure(context: Context): Int? {
        virtualDisplay?.display?.let { if (it.isValid) return it.displayId }
        release()

        return try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val t = HandlerThread("soskoify-hidden-display").also { it.start() }
            val r = ImageReader.newInstance(WIDTH, HEIGHT, PixelFormat.RGBA_8888, 2)
            // Drain frames so the producer never stalls
            r.setOnImageAvailableListener({ it.acquireLatestImage()?.close() }, Handler(t.looper))

            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            val vd = dm.createVirtualDisplay("Soskoify-hidden", WIDTH, HEIGHT, DPI, r.surface, flags)

            if (vd == null) {
                r.close(); t.quitSafely()
                Log.w(TAG, "createVirtualDisplay returned null")
                return null
            }
            thread = t; reader = r; virtualDisplay = vd
            val id = vd.display.displayId
            Log.d(TAG, "Hidden display created, id=$id")
            id
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create hidden display", e)
            release()
            null
        }
    }

    @Synchronized
    fun release() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        virtualDisplay = null; reader = null; thread = null
    }
}
